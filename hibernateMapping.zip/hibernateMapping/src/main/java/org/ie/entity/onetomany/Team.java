package org.ie.entity.onetomany;

import javax.persistence.Entity;
import javax.persistence.Id;
import java.util.List;

@Entity
public class Team {
    @Id
    private int teamNumber;
    private int noOfMembers;
    private String teamLeaderName;
    private List<TeamMember> teamMembers;
}
