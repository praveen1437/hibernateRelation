package org.ie.entity.onetomany;

import javax.persistence.Entity;
import javax.persistence.Id;
import java.util.List;

@Entity
public class TeamMember {
    @Id
    private int id;
    private String name;
    private String clanName;
    private String ability;

}
